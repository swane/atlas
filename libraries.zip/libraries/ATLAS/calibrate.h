
#ifndef calibrate_h
#define calibrate_h

#include "Arduino.h"
#include "calibrate.h"


void calibratemenu() ;
void calibratefrontsteer();
void calibraterearsteer();
void ATLASshow_location();
void ATLASshow_GPS();

void ATLASshow_bearing();
void show_calib_compass();
void ATLAScalib_compass();
void ATLASmagcalcompass();

#endif