#include<ATLAS.h>


#include "Arduino.h"
#include "calibrate.h"
#define btn_less 1
#define btn_select 2
#define btn_adv 3

double _ATLASLt, _ATLASLn;

double _ATLASdistance, _ATLASbearing,  _ATLASgoal_bear;
void ATLASshow_GPS()
{
  while (1) {
    double lt, ln;

    lt = getLat();
    ln = getLon();
    lcd.clear();
    lcd.print(lt, 6);
    lcd.setCursor(0, 1);
    lcd.print(ln, 6);
    delay(1000);
  }
}


void ATLASshow_bearing() {
  while (1) {
    double bearing = read_compass();

    display("Bearing", String(bearing));
    delay(100);
  }
}
void ATLASshow_temperature() {
  while (1) {
    double t = temp();

    display("Temperature", String(t));
    delay(100);
  }
}

void calibratemenu() {
  String a = ">";
  int menutitle = 0;
  int maxmenutitle = 4;
  int menuitem = 1;
  int maxmenu[4] = {5, 5, 3, 3};

  //First item is heading, second column starts selection
  String menu[4][7] = { {"Display", "GPS", "Bearing", "Front pot", "Rear Pot", "Temperature" },
    {"Calbrte Steer", "Front steer", "Rear steer", "Max Fr Steer", "Max Rr Steer","Clear"},
    {"Calbrte Sensor", "CompassGPS", "Compass Magnetic", "A1 Low:", "A1 High:", "" },
    {"PID", "Kp:", "Ki:", "Kd:", "Reset", "Save" },
  };
  int mode = 0;
  display(a + menu[menutitle][0], menu[0][1]);
  while (1) {
          if (edge_rising( btn_less)) {
      if (mode == 0)
      {

        menutitle--;
        if (menutitle == -1) menutitle = maxmenutitle;
        display(a + menu[menutitle][0], menu[menutitle][menuitem]);
      }
      if (mode == 1) {
        menuitem--;
        if (menuitem == 0) menuitem = maxmenu[menutitle];
        display(menu[menutitle][0], a + menu[menutitle][menuitem]);
      }
    }
    if (edge_rising( btn_adv)) {
      if (mode == 0)
      {

        menutitle++;
        if (menutitle == maxmenutitle)menutitle = 0;
        display(a + menu[menutitle][0], menu[menutitle][menuitem]);
      }
      if (mode == 1) {
        menuitem++;
        if (menuitem > maxmenu[menutitle]) menuitem = 1;
        display(menu[menutitle][0], a + menu[menutitle][menuitem]);
      }
    }
    if (edge_rising(btn_select)) {
      if (mode == 1) {
        lcd.clear();
        //display("SELECTED!");
        if ((menutitle == 1) && (menuitem == 1)) calibratefrontsteer();
        if ((menutitle == 1) && (menuitem == 2)) calibraterearsteer();
        if ((menutitle == 1) && (menuitem == 5)) clear_calibratesteer();
        if ((menutitle == 0) && (menuitem == 1)) ATLASshow_GPS();
        if ((menutitle == 0) && (menuitem == 2)) ATLASshow_bearing();
if ((menutitle == 0) && (menuitem == 5)) ATLASshow_temperature();

        if ((menutitle == 2) && (menuitem == 1)) show_calib_compass();
        if ((menutitle == 2) && (menuitem == 2)) ATLASmagcalcompass();
        //menuitem++;
        //display(menu[menutitle][0], a + menu[menutitle][menuitem]);
      }
      if (mode == 0) {
        display(menu[menutitle][0], a + menu[menutitle][menuitem]);
        mode = 1; delay(100);
      }
    }

  }
}
/*
void set_front_calibrate(int c);
void set_rear_calibrate(int c);
void read_front_calibrate();
*/
void calibratefrontsteer()  

{
  int front_offset=read_front_calibrate();
  display("1=+, 3=-", "2=Reset (" + String(front_offset) + ")");
  delay(200);
  while (1) {
    
    if (edge_rising(1)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      front_offset--;
      set_front_calibrate(front_offset);
      steer(0 );
      display("1=+, 3=-", "2=Reset (" + String(front_offset) + ")");
    }
    if (edge_rising(3)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      front_offset++;
      set_front_calibrate(front_offset);
      steer(0 );
     display("1=+, 3=-", "2=Reset (" + String(front_offset) + ")");
    }

    if (edge_rising(2)) {
        front_offset=0;
      display("Reset to zero", "Centre off:" + String(front_offset));


      set_front_calibrate(0);
      steer(0);
      delay(200);
    }
  }
}
void calibraterearsteer()
{
 
  int rear_offset=read_rear_calibrate();
  display("1=+, 3=-", "2=Reset (" + String(rear_offset) + ")");
  delay(200);
  while (1) {
    
    if (edge_rising(1)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      rear_offset--;
      set_rear_calibrate(rear_offset);
      rear_steer(0 );
      display("1=+, 3=-", "2=Reset (" + String(rear_offset) + ")");
    }
    if (edge_rising(3)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      rear_offset++;
      set_rear_calibrate(rear_offset);
      rear_steer(0 );
     display("1=+, 3=-", "2=Reset (" + String(rear_offset) + ")");
    }

    if (edge_rising(2)) {
        rear_offset=0;
      display("Reset to zero", "Centre off:" + String(rear_offset));


      set_rear_calibrate(0);
      rear_steer(0);
      delay(200);
    }
  }
}
void clear_calibratesteer()
{
    EEPROM.write(2, 0);
      EEPROM.write(0, 170); 
      EEPROM.write(1, 0);
}

void ATLASshow_location()
{

  lcd.clear();
  lcd.print(_ATLASLt, 6);
  lcd.setCursor(0, 1);
  lcd.print(_ATLASLn, 6);

}
void calib_ATLASshow_bearing()
{

  lcd.clear();
  lcd.print(_ATLASdistance);
  lcd.setCursor(0, 1);
  lcd.print(_ATLASgoal_bear); lcd.print(" : "); lcd.print(_ATLASbearing); delay(200);

}


void show_calib_compass()
{
  double goal_lat, goal_lon;
  static int state = 0;
  lcd.clear();
  display("Move to location", "Press btn 2"); delay(2000);

  set_timer(0, 200);
  while (1) {
    if (state == 0)
    {
      if (timer_elapsed(0))
      {
        _ATLASLt = getLat();
        _ATLASLn = getLon();
        ATLASshow_location();

        _ATLASdistance = distance_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);
        _ATLASgoal_bear = bearing_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);
        set_timer(0, 500);
      }
      if (edge_rising(2)) {
        goal_lat = getLat();
        goal_lon = getLon();
        display("Distance", "GPS B:Current B");
        delay(2000);
        state = 1;
      }
    }
    if (state == 1)
    {
      if (timer_elapsed(0))
      {
        _ATLASLt = getLat();
        _ATLASLn = getLon();


        _ATLASdistance = distance_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);
        _ATLASgoal_bear = bearing_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);

        set_timer(0, 500);
      }
      ATLAScalib_compass();
       if (edge_rising(2)) //Navigate to point
       {state=2;}
      _ATLASbearing = read_compass();
      calib_ATLASshow_bearing();
    }
  }
}

void ATLAScalib_compass() {

  double ob;
  if (edge_rising(1)) {
      if (read_button(3)){write_offset_bearing(0);
    ob = read_offset_bearing();}  //both buttons = reset to zero
    else{
   
    ob = read_offset_bearing();
    ob = ob - 1;
    write_offset_bearing(ob);
    ob = read_offset_bearing();
    }
  }
  if (edge_rising(3)) {
if (read_button(1)){write_offset_bearing(0);
    ob = read_offset_bearing();  //both buttons = reset to zero
}else{
    ob = read_offset_bearing();
    ob = ob + 1;
    write_offset_bearing(ob);
    ob = read_offset_bearing();
}
  }
 /* if (edge_rising(2)) {
    write_offset_bearing(0);
    ob = read_offset_bearing();
  }*/

}

void ATLASmagcalcompass() {
  while (1) {
    lcd.print("1-Del Cal,2-Sto Cal");
    if (read_button(1))del_compass_cal();
    if (read_button(2))store_compass_cal();

    double b;
    unsigned char c;

    b = read_compass();
    c = read_compass_cal();
    nextline_LCD();
    lcd.print(b);
    lcd.print(" Cal:");
    lcd.print(c);

    delay(100);
  }
}