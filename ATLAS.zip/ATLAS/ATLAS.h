/*
.h file
Maverick robot library
For the Summer School Robotics
GPS Robotics
Created by Samuel Wane, Harper Adams University, August 2015
Library folder adapted by Matt Butler March 2016
Updated for wireless summer 2016
REVISED APRIL 2020
*/


#ifndef ATLAS_h
#define ATLAS_h

#include "Arduino.h"


#include <math.h>
#include <stdlib.h>

#include <Wire.h>
#include <FreeSixIMU.h>
#include <NMEAGPS.h>
#include "deg2utm.h"
#include <VarSpeedServo.h>
#include <SPI.h>
#include <SD.h>
#include <LiquidCrystal.h>
#include <SoftwareSerial.h>
#include <EEPROM.h>

#ifndef SD_h
#define SD_h

#endif

//Gen IO
#define GENA1 A11
#define GENA2 A12
#define GENA3 A13
#define GENA4 A14
#define GENA5 A15

#define GEND1 30
#define GEND2 33
#define GEND3 32
#define GEND4 23
#define GEND5 3

//

extern LiquidCrystal lcd;
extern SoftwareSerial bluetooth; // RX, TX
class Timerclass
{
public:
	Timerclass();
	~Timerclass();
	unsigned long get_timerclass(int timer_no);
	void set_timerclass(int timer_no, unsigned long timerincrement);
	bool timer_elapsedclass(int timer_no);
private:
	unsigned long _timervar[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	bool _timer_elapsed[10] = { true, true, true, true, true, true, true, true, true, true };
};

void initialise();

double trailer_angle();
void set_trailer_centre();
unsigned long get_timer(int timer_no);
void set_timer(int timer_no, unsigned long timerincrement);
bool timer_elapsed(int timer_no);

void display(String topLine);

void display(String topLine, String bottomLine );

void steer(double steer_angle);
void steerc(double steer_angle);
double read_steer(double steer_angle);
void set_front_calibrate(int c);
void set_rear_calibrate(int c);
int read_front_calibrate();
int read_rear_calibrate();

void rear_steer(double steer_angle);
void steerslow(double steer_angle);
void rear_steerslow(double steer_angle);
double steer_radius(double inv_R); //Returns steer angle from Inverse Radius (1/R), vehicle length defined in .cpp file
void drive(float drive_speed);
void drive(float drive_speed, byte accel);
void front_drive(float drive_speed);
void rear_drive(float drive_speed);

void front_RC(float drive_speed);
void rear_RC(float drive_speed);


void set_veh_length(double v);
void set_veh_width(double v);
void set_max_steerf(double s);
void set_min_steerf(double s);

void turret(int angle);
void turret(int steer_angle, byte speed);
void turret(int steer_angle, byte speed, bool block);
double rightLDR();
double leftLDR();

double read_distance();
void clear_LCD();
void nextline_LCD();
double read_compass(void);
double closest_bearing_difference(double current_bearing, double goal_bearing);
double bearing_to_point_UTM(double current_northing, double current_easting, double goal_northing, double goal_easting);
double distance_to_point_UTM(double current_northing, double current_easting, double goal_northing, double goal_easting);

double bearing_to_point_deg(double current_lat, double current_lon, double goal_lat, double goal_lon);
double distance_to_point_deg(double current_lat, double current_lon, double goal_lat, double goal_lon);

void calc_x_track(double* AimN, double* AimE, double S_N,double S_E,double E_N, double E_E,double CN,double CE,double Aimdist);

double calc_x_track_bear(double S_lat,double S_lon,double E_lat, double E_lon,double C_lat,double C_lon,double Aimdist);


double drive_target(double goal_northing, double goal_easting, double offset);
double follow_wall(double des_dist, double gain);
bool edge_rising(int port);
bool scan(int stand_out, int* distr, int* bearr); //Returns 999,999 if not found
double RC_speed();
double RC_steer();
void sweep(int *scanarray); //returns array of scans 10 deg apart
double Output_PID(double Kp, double Ki, double Kd, double error, double maxerror);
double Output_PID(double Kp, double Ki, double Kd, double error);
double filter(double input, double f);

int read_button(int button);
void led_out(int led,bool value);
void buzzer_on();
void buzzer_off();
float right_light();
float left_light();
double gen_pot();
double rev_pot();
bool approx(double a,double b,double t);
double battery();
void imu_init();
float get_Yaw();
float get_Pitch();
float get_Roll();
float getLat();
float getLon();
float getAlt();
float getN();
float getE();
float temp();
void initSD();
void openSD();
double read_offset_bearing();
void write_offset_bearing(double ob);
void readnum2(File f, double* a, double* b);
void readnum3(File f, double* a, double* b, double* d);
bool DIP(int d);
byte readDIP();
unsigned long read_wheel();
void zero_wheel();
#endif

