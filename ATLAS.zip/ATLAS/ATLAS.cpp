/*
  .cpp file
  Maverick robot library
  For the Summer School Robotics
  GPS Robotics
  Created by Samuel Wane, Harper Adams University, August 2015
  Adapted for single folder library Matt Butler April 2016
  Updated for wireless summer 2016
  Renamed ATLAS summer 2018
  Updated to parallel LCD and using external libraries Sept 2020
*/


#include "ATLAS.h"
//Vehicle length (m) for 1/R steer calculation
double veh_length = 0.6;
double veh_width = 0.5;
//IMU variable
FreeSixIMU imu;

//GPS NEOGPS
#define gpsPort Serial1
#define GPS_PORT_NAME "Serial1"
#define DEBUG_PORT Serial


NMEAGPS  gps; // This parses the GPS characters
gps_fix  fix; // This holds on to the latest values

String lastMessage; // not happy with this
String lastMessage1;
String lastMessage2;



static void GPSisr()
{
  if (gps.available(gpsPort))
    fix = gps.read();
}


// initialize the LCD library with the numbers of the
SoftwareSerial bluetooth(23, 22); // RX, TX

//setup pins for Arduino Mega 2560 built NUL 2021

//Motors
#define frontservo 6
#define rearservo 35

#define L298REAR1 8
#define L298REAR2 9
#define L298FRONT1 10
#define L298FRONT2 11

//Hall
#define HALL_SENSOR 2
//LDR
#define _rightLDR A2
#define _leftLDR A3
//Battery
#define battmon A0
#define genpot A8
#define revpot A1

//LiquidCrystal lcd(R5,E,D4,D5,D6,D7);
#define R5 13
#define E 22
#define D4 25
#define D5 24
#define D6 26


//Ultrasonic
#define trigpinNew 29
#define echopinNew 27

#define buzzpin 28

#define D7 31
//Radio control input, 1 is steer in range -1 - +1 (right), input 2 speed -1 to +1(trigger pulled)
#define RCINpin1 37
#define RCINpin2 36

#define led1 39
#define led2 41
#define led3 43

#define DIP1 38
#define DIP2 40
#define DIP3 42
#define DIP4 44

#define button1 45
#define button2 47
#define button3 49
//Old ultrasonic
#define echopin 49


//old ultrasonic
#define trigpin 51
//SD Card


#define CS 52
#define SDI 50
#define SDO 51
#define CLK 53
// change this to match your SD shield or module;
const int chipSelect = 53;

//Servos
//set limits and create steering servo object
double steer_angle_max = 40;
double steer_angle_min = -40;

int front_offset = 0, rear_offset = 0;
//VarSpeedServo steerservo;
VarSpeedServo frservo;
VarSpeedServo rrservo;

//driving wheels control
#define driveservopin 4
VarSpeedServo driveservo;

//set limits and create turret servo object
#define turretservopin 10
#define turret_max 175
#define turret_min 15
VarSpeedServo turretservo;



LiquidCrystal lcd(R5, E, D4, D5, D6, D7);


//Compass
#define I2C_Address 0x60   // Defines address of CMPS11
const unsigned int MAX_INPUT = 200;
#define CMPS_GET_ANGLE8 0x12
#define CMPS_GET_ANGLE16 0x13
#define CMPS_GET_PITCH 0x14
#define CMPS_GET_ROLL 0x15

SoftwareSerial compassserial = SoftwareSerial(12, 34); // RX, TX

//Gen IO
#define GENA1 A11
#define GENA2 A12
#define GENA3 A13
#define GENA4 A14
#define GENA5 A15

#define GEND1 30
#define GEND2 33
#define GEND3 32
#define GEND4 23
#define GEND5 3











// Functions for the timer
Timerclass::Timerclass() {}
Timerclass::~Timerclass() {}


Timerclass timer;


double offset_bearing = 0;



unsigned long Timerclass::get_timerclass(int timer_no) {
  return _timervar[timer_no];
}

void Timerclass::set_timerclass(int timer_no, unsigned long timerincrement)
{
  if (_timer_elapsed[timer_no])
  {
    _timervar[timer_no] = millis() + timerincrement;
    _timer_elapsed[timer_no] = false;
    // set_statei(_timerstate);
  }
  /*if (get_state()!=_timerstate)
    {
    _timervar=millis()+timerincrement;
    set_statei(_timerstate);
    }*/
}
bool Timerclass::timer_elapsedclass(int timer_no)
{
  bool elapsed = millis() > get_timerclass(timer_no);
  // if (elapsed) _timer_elapsed=true;
  _timer_elapsed[timer_no] = elapsed;
  return (elapsed);

}


unsigned long get_timer(int timer_no) {
  return timer.get_timerclass(timer_no);
}

void set_timer(int timer_no, unsigned long timerincrement) {
  timer.set_timerclass(timer_no, timerincrement);
}

bool timer_elapsed(int timer_no) {
  return timer.timer_elapsedclass(timer_no);

}
void display(String topLine) {

  lastMessage1 = ""; lastMessage2 = "";

  if (topLine != lastMessage) {

    lcd.clear();
    lcd.print(topLine.substring(0, 16));

    lastMessage = topLine;
  }
}



void display(String topLine, String bottomLine ) {

  lastMessage = "";

  if ((topLine != lastMessage1) || (bottomLine != lastMessage2)) {

    lcd.clear();
    lcd.print(topLine.substring(0, 16));
    lcd.setCursor(0, 1);
    lcd.print(bottomLine.substring(0, 16));

    lastMessage1 = topLine;
    lastMessage2 = bottomLine;
  }
}


double gen_pot()
{
  return analogRead(genpot);
}
double rev_pot()
{
  return analogRead(revpot);
}
double battery()
{
  return analogRead(battmon);
}


bool approx(double a, double b, double t)
{
  return abs(a - b) < t;
}

void set_veh_length(double v)
{
  veh_length = v;
}
void set_veh_width(double v)
{
  veh_width = v;
}

double steer_radius(double inv_R) //Inverse radius of the steer circle
{
  double steer_angle;
  double Radius = 1 / inv_R;
  double s = -1;
  if (Radius < 0) {
    s = 1;
    Radius = -Radius;
  }
  steer_angle = s * atan((2 * veh_length) / (2 * (Radius) - veh_width)) * 57.3;
  return steer_angle;
}
void set_max_steerf(double s)
{
  steer_angle_max = s;
}
void set_min_steerf(double s)
{
  steer_angle_min = s;
}

void steer(double steer_angle) //Front servo only
{
  steer_angle = steer_angle + front_offset;
  if (steer_angle > steer_angle_max) steer_angle = steer_angle_max;
  if (steer_angle < steer_angle_min) steer_angle = steer_angle_min;
  steer_angle = -steer_angle + 90; //Central = 90
  frservo.attach(frontservo);
  frservo.write(steer_angle);


  delay(50);
  frservo.detach();
}
void steerc(double steer_angle) //Front servo only
{
  steer_angle = steer_angle + front_offset;

  steer_angle = -steer_angle + 90; //Central = 90
  frservo.attach(frontservo);
  frservo.write(steer_angle);


  delay(50);
  frservo.detach();
}

double read_steer(double steer_angle)
{
  if (steer_angle > steer_angle_max) steer_angle = steer_angle_max;
  if (steer_angle < steer_angle_min) steer_angle = steer_angle_min;
  steer_angle = -steer_angle + 90; //Central = 90

  return steer_angle;

}
void rear_steer(double steer_angle) //Rear servo only
{
  steer_angle = steer_angle + rear_offset;

  if (steer_angle > steer_angle_max) steer_angle = steer_angle_max;
  if (steer_angle < steer_angle_min) steer_angle = steer_angle_min;
  steer_angle = -steer_angle + 90; //Central = 90
  rrservo.attach(rearservo);
  rrservo.write(steer_angle);


  delay(50);
  rrservo.detach();

}
void set_front_calibrate(int c)
{
  front_offset = c;
}
int read_front_calibrate()
{
  return front_offset;
}
int read_rear_calibrate()
{
  return rear_offset;
}

void set_rear_calibrate(int c)
{
  rear_offset = c;
}

void steerslow(double steer_angle) //Front servo only
{
  steer_angle = -steer_angle + 90; //Central = 90
  if (steer_angle > steer_angle_max) steer_angle = steer_angle_max;
  if (steer_angle < steer_angle_min) steer_angle = steer_angle_min;
  frservo.attach(frontservo);

  frservo.write(steer_angle, 6); //10 takes 1.5 seconds to move 30 degrees

  delay(50);
  frservo.detach();

}
void rear_steerslow(double steer_angle) //Rear servo only
{
  steer_angle = -steer_angle + 90; //Central = 90
  if (steer_angle > steer_angle_max) steer_angle = steer_angle_max;
  if (steer_angle < steer_angle_min) steer_angle = steer_angle_min;
  rrservo.attach(rearservo);

  rrservo.write(steer_angle, 6);
  delay(50);
  rrservo.detach();
}


void drive(float drive_speed) // input is < 1 Metre per Sec
{
  int new_num = drive_speed * 100; // x 100 to simplify and use integers
  float sp;
  sp = drive_speed; //Used in L298 control
  if (new_num > 0) {

    new_num = constrain(new_num, 10, 100);
    drive_speed = map(new_num, 10, 100, 10, 45);
  }

  if (new_num < 0) {

    new_num = constrain(new_num, -100, -10);
    drive_speed = map(new_num, -100, -10, -45, -10);
  }

  //drive_speed=drive_speed+90; //stopped = 90]
  drive_speed = drive_speed + 90;

  driveservo.attach(driveservopin);



  driveservo.write(drive_speed);
  delay(50);
  driveservo.detach();
  //L298 control, both rear and front

  if (sp > 1) sp = 1;
  if (sp < -1) sp = -1;
  if (sp == 0)
  {
    digitalWrite(L298REAR1, LOW);
    digitalWrite(L298REAR2, LOW);
    digitalWrite(L298FRONT1, LOW);
    digitalWrite(L298FRONT2, LOW);
  }
  if (sp < 0)
  {
    digitalWrite(L298REAR1, LOW);
    analogWrite(L298REAR2, -sp * 255);
    digitalWrite(L298FRONT2, LOW);
    analogWrite(L298FRONT1, -sp * 255);
  }
  if (sp > 0)
  {
    digitalWrite(L298REAR2, LOW);
    analogWrite(L298REAR1, sp * 255);
    digitalWrite(L298FRONT1, LOW);
    analogWrite(L298FRONT2, sp * 255);
  }

}

void drive(float drive_speed, byte accel) // input is < 1 Metre per Sec
{
  int new_num = drive_speed * 100; // x 100 to simplify and use integers

  if (new_num > 0) {

    new_num = constrain(new_num, 10, 100);
    drive_speed = map(new_num, 10, 100, 10, 45);
  }

  if (new_num < 0) {

    new_num = constrain(new_num, -100, -10);
    drive_speed = map(new_num, -100, -10, -45, -10);
  }

  //drive_speed=drive_speed+90; //stopped = 90]
  drive_speed = drive_speed + 90;
  driveservo.attach(driveservopin);



  driveservo.write(drive_speed, accel);
  delay(50);
  driveservo.detach();


}
void front_drive(float drive_speed)
{
  int new_num = drive_speed * 100; // x 100 to simplify and use integers
  float sp;
  sp = drive_speed; //Used in L298 control

  if (sp > 1) sp = 1;
  if (sp < -1) sp = -1;
  if (sp == 0)
  {

    digitalWrite(L298FRONT1, LOW);
    digitalWrite(L298FRONT2, LOW);
  }
  if (sp < 0)
  {
    digitalWrite(L298FRONT2, LOW);
    analogWrite(L298FRONT1, -sp * 255);
  }
  if (sp > 0)
  {

    digitalWrite(L298FRONT1, LOW);
    analogWrite(L298FRONT2, sp * 255);
  }

}
void rear_drive(float drive_speed)
{
int new_num = drive_speed * 100; // x 100 to simplify and use integers
float sp;
sp = drive_speed; //Used in L298 control

if (sp > 1) sp = 1;
if (sp < -1) sp = -1;
if (sp == 0)
{
  digitalWrite(L298REAR1, LOW);
  digitalWrite(L298REAR2, LOW);

}
if (sp < 0)
{
  digitalWrite(L298REAR1, LOW);
  analogWrite(L298REAR2, -sp * 255);

}
if (sp > 0)
{
  digitalWrite(L298REAR2, LOW);
  analogWrite(L298REAR1, sp * 255);

}

}
void front_RC(float drive_speed)
{
  driveservo.attach(driveservopin);
  driveservo.write(drive_speed);
  delay(50);
  driveservo.detach();
}
void rear_RC(float drive_speed)
{
  rrservo.attach(rearservo);


  rrservo.write(drive_speed);
  delay(50);
  rrservo.detach();
}

void turret(int steer_angle)
{
  steer_angle = steer_angle + 90; //Central = 90
  if (steer_angle > turret_max) steer_angle = turret_max;
  if (steer_angle < turret_min) steer_angle = turret_min;
  turretservo.attach(turretservopin);
  turretservo.write(steer_angle);
  delay(50);
  turretservo.detach();
}

void turret(int steer_angle, byte speed)
{
  steer_angle = steer_angle + 90; //Central = 90
  if (steer_angle > turret_max) steer_angle = turret_max;
  if (steer_angle < turret_min) steer_angle = turret_min;
  turretservo.attach(turretservopin);
  turretservo.write(steer_angle, speed);
  delay(50);
  turretservo.detach();

}

void turret(int steer_angle, byte speed, bool block) // block pauses program until position reached
{
  steer_angle = steer_angle + 90; //Central = 90
  if (steer_angle > turret_max) steer_angle = turret_max;
  if (steer_angle < turret_min) steer_angle = turret_min;
  turretservo.attach(turretservopin);
  turretservo.write(steer_angle, speed, block);
  delay(50);
  turretservo.detach();

}



double read_distance()
{
  // establish variables for duration of the ping,
  // and the distance result in inches and centimeters:
  long duration;

  // The PING))) is triggered by a HIGH pulse of 2 or more microseconds on the 'trig' pin.
  // Give a short LOW pulse beforehand to ensure a clean HIGH pulse:
  digitalWrite(trigpinNew, LOW);
  delayMicroseconds(2);
  digitalWrite(trigpinNew, HIGH);
  delayMicroseconds(5);
  digitalWrite(trigpinNew, LOW);

  // The echo pin is used to read the signal from the sensor a HIGH
  // pulse whose duration is the time (in microseconds) from the sending
  // of the ping to the reception of its echo off of an object.

  duration = pulseIn(echopinNew, HIGH);

  // convert the time into a distance cm

  return double(duration) / 29 / 2;

}

void clear_LCD() {
  Serial3.write(0xFE); Serial3.write(0x01); //Clear LCD
  lcd.clear();
  lcd.setCursor(0, 0);
}
void nextline_LCD() {
  Serial3.write(0xFE); Serial3.write(192); //Next LCD Line
  lcd.setCursor(0, 1);
}

double read_compass()
{
  unsigned int angle16;
  unsigned char high_byte, low_byte;
  compassserial.write(CMPS_GET_ANGLE16);  // Request and read 16 bit angle
  unsigned long m;
  m = millis();
  bool timeout;
  timeout = false;
  while ((compassserial.available() < 2) && (!timeout))
  {
    if (millis() - m > 500) timeout = true;
  }
  if (!timeout)
  {
    high_byte = compassserial.read();
    low_byte = compassserial.read();
    angle16 = high_byte;                // Calculate 16 bit angle
    angle16 <<= 8;
    angle16 += low_byte;
  } else angle16 = 9999;

  double bearing = angle16 / 10;
  bearing = bearing + offset_bearing;
  if (bearing > 359) bearing = bearing - 360;
  if (bearing < 0) bearing = bearing + 360;
  return bearing;
}

double read_compass_i2c_old(void)
{
  unsigned char high_byte, low_byte, angle8;
  char pitch, roll;
  unsigned int angle16;
  //byte highByte, lowByte, fine;              // highByte and lowByte store high and low bytes of the bearing and fine stores decimal place of bearing
  double bearing;                               // Stores full bearing

  Wire.beginTransmission(I2C_Address);           //starts communication with CMPS10
  Wire.write(1);                             //Sends the register we wish to start reading from
  Wire.endTransmission();

  Wire.requestFrom(I2C_Address, 5);              // Request 4 bytes from CMPS10
  while (Wire.available() < 5);               // Wait for bytes to become available
  angle8 = Wire.read();               // Read back the 5 bytes
  high_byte = Wire.read();
  low_byte = Wire.read();
  pitch = Wire.read();
  roll = Wire.read();
  //highByte = Wire.read();
  //lowByte = Wire.read();
  angle16 = high_byte;                 // Calculate 16 bit angle
  angle16 <<= 8;
  angle16 += low_byte;
  bearing = (double)angle16 / 10;      // Calculate full bearing


  return bearing;

}


double closest_bearing_difference(double current_bearing, double goal_bearing)
{
  double cl_bearing;
  cl_bearing = goal_bearing - current_bearing;
  if (cl_bearing > 180) cl_bearing = (cl_bearing - 360);
  if (cl_bearing < -180) cl_bearing = (cl_bearing + 360);
  return cl_bearing;
}
double resolve_bearing(double bearing)
{
  if (bearing > 360) bearing = bearing - 360 * int(bearing / 360);
  if (bearing < 0) bearing = bearing + 360 * (int(-bearing / 360) + 1);
  return bearing;
}

double bearing_to_point_UTM(double current_northing, double current_easting, double goal_northing, double goal_easting)
{
  double bear_pt;
  bear_pt = double(atan2(goal_easting - current_easting, goal_northing - current_northing) / M_PI * 180);
  bear_pt = resolve_bearing(bear_pt);
  return bear_pt;
}

double distance_to_point_UTM(double current_northing, double current_easting, double goal_northing, double goal_easting)
{
  double dist;
  dist = double(sqrt((current_northing - goal_northing) * (current_northing - goal_northing) + (current_easting - goal_easting) * (current_easting - goal_easting)));
  return dist;
}
double bearing_to_point_deg(double current_lat, double current_lon, double goal_lat, double goal_lon)
{
  double current_northing, current_easting, goal_northing, goal_easting;
  double bear_pt;
  deg2utm(current_lat, current_lon, &current_northing, &current_easting);
  deg2utm(goal_lat, goal_lon, &goal_northing, &goal_easting);
  bear_pt = double(atan2(goal_easting - current_easting, goal_northing - current_northing) / M_PI * 180);
  bear_pt = resolve_bearing(bear_pt);
  return bear_pt;
}

double distance_to_point_deg(double current_lat, double current_lon, double goal_lat, double goal_lon)
{
  double current_northing, current_easting, goal_northing, goal_easting;
  double dist;
  deg2utm(current_lat, current_lon, &current_northing, &current_easting);
  deg2utm(goal_lat, goal_lon, &goal_northing, &goal_easting);
  dist = double(sqrt((current_northing - goal_northing) * (current_northing - goal_northing) + (current_easting - goal_easting) * (current_easting - goal_easting)));
  return dist;
}

void calc_x_track(double* AimN, double* AimE, double S_N,double S_E,double E_N, double E_E,double CN,double CE,double Aimdist)
{
  double AP2,AF,AB,FP;
  double Ef,Nf;
 
  AP2=(CE-S_E)*(CE-S_E)+(CN-S_N)*(CN-S_N);
    AF=((S_E-CE)*(S_E-E_E)+(S_N-CN)*(S_N-E_N))/(sqrt((S_E-E_E)*(S_E-E_E)+(S_N-E_N)*(S_N-E_N)));
    FP=sqrt(AP2-AF*AF);

    //Perpendicular point on tracked line (Fx, Fy)
    AB=sqrt((S_E-E_E)*(S_E-E_E)+(S_N-E_N)*(S_N-E_N));
    Ef=S_E+(E_E-S_E)*(AF/AB);
    Nf=S_N+(E_N-S_N)*(AF/AB);

    //Aim
    *AimE=Ef+(E_E-S_E)*(Aimdist/AB);
    *AimN=Nf+(E_N-S_N)*(Aimdist/AB);
    
}

double follow_wall(double des_dist, double gain)
{
  static double act_dist;
  double error;
  static unsigned long int_time = 0;

  if (millis() > int_time)
  {

    int_time = millis() + 100;

    act_dist = read_distance();
    error = des_dist - act_dist;
    error = error * gain;
    steer(error);
    //if (dist>5) drive(1);else drive(0);
  }

  return act_dist;
}

bool edge_rising(int port)
{
  bool edge;
  static bool prev[4] = { LOW, LOW, LOW, LOW };
  if (read_button(port) && !prev[port]) {
    edge = HIGH;
    prev[port] = HIGH;
  }
  else edge = LOW;
  if (!read_button(port)) prev[port] = LOW;
  return edge;
}

double drive_target(double goal_northing, double goal_easting, double offset)
{
  double lt, ln, UTMNorthing, UTMEasting, current_bearing, closest_bearing;
  static int int_time = 0;
  static double dist = 0, goal_bearing = 0;
  if (millis() > int_time)
  {
    //Recalculate bearing based on current point and goal

    int_time = millis() + 1000;

    lt = getLat();
    ln = getLon();
    deg2utm(lt, ln, &UTMNorthing, &UTMEasting);
    dist = distance_to_point_UTM(UTMNorthing, UTMEasting, goal_northing, goal_easting);
    goal_bearing = bearing_to_point_UTM(UTMNorthing, UTMEasting, goal_northing, goal_easting);
    goal_bearing = goal_bearing + offset;
    if (goal_bearing > 359) goal_bearing = goal_bearing - 359;
    if (goal_bearing < 0) goal_bearing = goal_bearing + 359;

    //if (dist>5) drive(1);else drive(0);
  }
  current_bearing = read_compass();
  closest_bearing = closest_bearing_difference(current_bearing, goal_bearing);
  //steer(closest_bearing);

  return closest_bearing;
}

void sweep(int *scanarray)
{

  int arpos = 0;
  int n;
  turret(-90); delay(500);
  for (n = -90; n < 90; n += 10)
  {
    turret(n);

    delay(100);
    scanarray[arpos] = read_distance();
    arpos++;

  }

}

//left =1891, right=1056 centre=1470 channel 1 RCINpin1
// trig pulled 1057, middle=1482, pushed 1912  channel 2 RCINpin2

bool scan(int stand_out, int* distr, int* bearr) //Returns 999,999 if not found
{
  int n;
  int found_mode = 0; //state=0 not found an object,1=object found
  bool found_anything = 0;
  int start_obj, end_obj;
  int dist, prevdist;
  int scan_array_pos = 0;
  int closest_obj = 999, closest_obj_angle = 999;
  float closest_obj_angle_f = 999;

  found_anything = 0;
  found_mode = 0;
  closest_obj = 999;
  turret(-80);
  Serial.print(":");
  delay(500);
  for (n = -80; n < 80; n += 5)
  {
    turret(n);
    dist = read_distance();
    Serial.print(dist);
    Serial.print(",");
    delay(80);
    if (n > -80) //don't do at the start of the scan
    {
      if (((prevdist - dist) > stand_out) && (found_mode == 0))
      {
        if (dist + 10 < closest_obj)
        {
          found_mode = 1;
          start_obj = n;
        }
      }
    }
    if ((found_mode == 1) && ((dist - prevdist) > stand_out))
    {
      end_obj = n;
      found_mode = 0;
      found_anything = 1;
      closest_obj_angle_f = start_obj + ((end_obj - start_obj) / 2) - 10;
      closest_obj_angle = (int)closest_obj_angle_f;
    }
    if ((found_mode == 1) && (dist < closest_obj)) closest_obj = dist;

    // if (dist<closest_obj) {closest_obj=dist;closest_obj_angle=n;}
    prevdist = dist;
  }
  *distr = closest_obj_angle;
  *bearr = closest_obj;
  return found_anything;
}

double Output_PID(double Kp, double Ki, double Kd, double error)
{

  static double lastmillisp;
  static double integError = 0, lastError;
  double dt;
  unsigned long tt;
  double compP, compI, compD;

  dt = (millis() - lastmillisp) / 1000.00;
  integError += error * dt;
  compP = error * Kp;
  compI = integError * Ki;
  compD = ((error - lastError) / dt) * Kd;
  lastError = error;
  lastmillisp = millis();
  return compP + compI + compD;
}
double Output_PID(double Kp, double Ki, double Kd, double error, double maxerror)
{
  static double lastmillisp;
  static double integError = 0, lastError;
  double dt;
  unsigned long tt;
  double compP, compI, compD;

  dt = (millis() - lastmillisp) / 1000.00;
  // if (error>maxerror) integError=0;
  // if (error<-maxerror) integError=0;

  if ((error > -maxerror) && (error < maxerror))integError += error * dt;
  compP = error * Kp;
  compI = integError * Ki;
  compD = ((error - lastError) / dt) * Kd;
  lastError = error;
  lastmillisp = millis();
  return compP + compI + compD;
}

double filter(double input, double f)
{
  static bool initialise = true;
  static double prev_x = 0, prev_y = 0;
  double y;
  double T;
  static unsigned long lastmillis;

  T = (millis() - lastmillis) / 1000.00;

  //f = 0.2; //Cutoff frequency in Hz, small value makes a slow response
  f = f * 2 * PI;
  //if (initialise) y = input; else
  y = f * T * prev_x + prev_y - f * T * prev_y;
  initialise = false;
  prev_x = input;
  prev_y = y;
  lastmillis = millis();
  return y;
}

void imu_init()
{
  imu.init();
}

float get_Yaw()
{
  float angles[3];
  imu.getYawPitchRoll(angles);
  return angles[0];
}
float get_Roll()
{
  float angles[3];
  imu.getYawPitchRoll(angles);
  return angles[2];
}
float get_Pitch()
{
  float angles[3];
  imu.getYawPitchRoll(angles);
  return angles[1];
}

float getLat()
{
  return fix.latitude();
}
float getLon()
{
  return fix.longitude();
}
float getAlt()
{
  return fix.altitude();
}
float getE()
{
  double GPSN, GPSE;
  deg2utm(getLat(), getLon(), &GPSN, &GPSE);
  return GPSE;
}
float getN()
{
  double GPSN, GPSE;
  deg2utm(getLat(), getLon(), &GPSN, &GPSE);
  return GPSN;
}
//Use leds eg  digitalWrite(led1, HIGH);
void led_out(int led, bool value)
{
  if (led == 1) digitalWrite(led1, value);
  if (led == 2) digitalWrite(led2, value);
  if (led == 3) digitalWrite(led3, value);
}
int read_button(int button)
{
  int buttonno = 1;
  if (button == 3) buttonno = button3;
  if (button == 2) buttonno = button2;
  if (button == 1) buttonno = button1;
  return !digitalRead(buttonno);
}

void buzzer_on()
{
  digitalWrite(buzzpin, HIGH);
}
void buzzer_off()
{
  digitalWrite(buzzpin, LOW);
}

float left_light()
{
  float a = (100 - (100 * ((float)analogRead(3) / 1023)));
  return a;
}
float right_light()
{
  float a = (100 - (100 * ((float)analogRead(2) / 1023)));
  return a;
}

float mapf(float x, float in_min, float in_max, float out_min, float out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

float temp()
{
  float a = 5 * (float)analogRead(A6) / 1023;
  float b = mapf(a, 0.3, 1.0, -25.0, 50);
  return b;
}


double RC_speed() {

  double spd;
  unsigned long t;

  t = millis();
  while ((!digitalRead(RCINpin2)) && (millis() - t < 50))
  {

  }
  t = micros();

  while ((digitalRead(RCINpin2)) && (micros() - t < 5000))
  {

  }
  unsigned long d = micros() - t;

  spd = 1 - (((double)d - 1000) * 2 / (1000) ); //Range -1 - 0 - +1
  if (spd > 1.5) spd = 2.0;
  return spd;
}

double RC_steer() {

  double spd;
  unsigned long t;

  t = millis();
  while ((!digitalRead(RCINpin1)) && (millis() - t < 50))
  {

  }
  t = micros();

  while ((digitalRead(RCINpin1)) && (micros() - t < 5000))
  {

  }
  unsigned long d = micros() - t;

  spd = 1 - (((double)d - 1000) * 2 / (1000) ); //Range -1 - 0 - +1
  if (spd > 1.5) spd = 2.0;
  return spd;
}



void initSD()
{
  if (!SD.begin()) {  //Init SD card
    Serial.println("SD card initialisation failed!");
  }
}
//SD card functions to read 2 or 3 numbers separated with commas and terminted with chr(13)
void readnum2(File f, double* a, double* b)
{
  char input[50];
  char str_split_result[5][10];
  char * token;
  int n = 0;
  bool cfound = false;
  char c;
  int m = 0;
  while (!cfound) {
    c = f.read();
    input[m++] = c;
    if (c == '\n') cfound = true;
  }

  token = strtok(input, ",");
  while (token != NULL)
  {
    strcpy(str_split_result[n], token);
    n++;
    token = strtok(NULL, ",");
  }
  *a = strtod(str_split_result[0], NULL);
  *b = strtod(str_split_result[1], NULL);
}
void readnum3(File f, double* a, double* b, double* d)
{
  char input[50];
  char str_split_result[5][10];
  char * token;
  int n = 0;
  bool cfound = false;
  char c;
  int m = 0;
  while (!cfound) {
    c = f.read();
    input[m++] = c;
    if (c == '\n') cfound = true;
  }

  token = strtok(input, ",");
  while (token != NULL)
  {
    strcpy(str_split_result[n], token);
    n++;
    token = strtok(NULL, ",");
  }
  *a = strtod(str_split_result[0], NULL);
  *b = strtod(str_split_result[1], NULL);
  *d = strtod(str_split_result[2], NULL);
}

bool DIP(int d)
{
bool r=false;
if (d==1) r=digitalRead(DIP1);
if (d==2) r=digitalRead(DIP2);
if (d==3) r=digitalRead(DIP3);
if (d==4) r=digitalRead(DIP4);
return r;
}
byte readDIP()
{
  byte a;
  a = digitalRead(DIP1);
  a = a + (2 * digitalRead(DIP2));
  a = a + (4 * digitalRead(DIP3));
  a = a + (8 * digitalRead(DIP4));
  return a;
}

unsigned long wheel = 0;
double read_offset_bearing()
{
  double o;
  o = EEPROM.read(7);
  if (o > 128) o = o - 255;
  offset_bearing = o;
  return o;
}

void write_offset_bearing(double ob)
{
  offset_bearing = ob;

  if (ob < 0) ob = 255 + ob;
  EEPROM.write(7, (byte)ob);
}
void countWheel() //HALL SENSOR interrupt
{
  if (digitalRead(HALL_SENSOR)) wheel++;
}
void zero_wheel()
{
  wheel = 0;
}
unsigned long read_wheel()
{
  return wheel;
}

void initz() {
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(led3, OUTPUT);
  led_out(1, LOW);
  led_out(2, LOW);
  led_out(3, LOW);


  pinMode(button1, INPUT_PULLUP);
  pinMode(button2, INPUT_PULLUP);
  pinMode(button3, INPUT_PULLUP);
  pinMode(DIP1, INPUT_PULLUP);
  pinMode(DIP2, INPUT_PULLUP);
  pinMode(DIP3, INPUT_PULLUP);
  pinMode(DIP4, INPUT_PULLUP);


  pinMode(buzzpin, OUTPUT); //Buzzer
  //Steer servos
  pinMode(L298REAR1, OUTPUT);
  pinMode(L298REAR2, OUTPUT);
  pinMode(L298FRONT1, OUTPUT);
  pinMode(L298FRONT2, OUTPUT);
  pinMode(RCINpin1, INPUT);
  pinMode(RCINpin2, INPUT);
  pinMode(trigpinNew, OUTPUT);
  pinMode(echopinNew, INPUT);

  pinMode(GEND1, INPUT_PULLUP);
  pinMode(GEND2, INPUT_PULLUP);
  pinMode(GEND3, INPUT_PULLUP);
  pinMode(GEND4, INPUT_PULLUP);
  pinMode(GEND5, INPUT_PULLUP);


  imu.init(true);
  //Communication ports
  Serial.begin(9600); //General Serial monitor
  gpsPort.begin(9600); //GPS port Serial1
  Serial2.begin(9600); //Wireless HC-11 Serial2
  attachInterrupt(digitalPinToInterrupt(19), GPSisr, RISING); //GPS interrupt on serial port pin
  //Steer servos



  Wire.begin();
  lcd.begin(16, 2); //16 x 2 LCD

  Serial3.begin(9600);
  bluetooth.begin(9600);
  compassserial.begin(9600);
  //HALL
  pinMode(HALL_SENSOR, INPUT);

  attachInterrupt(digitalPinToInterrupt(HALL_SENSOR), countWheel, CHANGE);

  //Read callibration offsets
  front_offset = 0; rear_offset = 0;

  byte b = EEPROM.read(0);
  if (b == 170) //callibration has been done
  {
    b = EEPROM.read(1);
    front_offset = (int)b;
    if (front_offset > 128) front_offset = 128 - front_offset;
    b = EEPROM.read(2);
    rear_offset = (int)b;
    if (rear_offset > 128) rear_offset = 128 - rear_offset;
    steer_angle_max = (double)(EEPROM.read(4));
    steer_angle_min = -(double)(EEPROM.read(3));
  }

  offset_bearing = read_offset_bearing();



rear_steer(0);

  steer(0);
  delay(100);
steer(0);

  rear_steer(0);
}

void initialise() {
  initz();
}

